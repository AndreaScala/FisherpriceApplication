use ELENCO;
create TABLE LOG(timestamp TIMESTAMP, idMacchina VARCHAR(255), message VARCHAR(255));
